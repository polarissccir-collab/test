<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="bg-white rounded-xl shadow-sm p-6">
      <h2 class="text-2xl font-bold text-gray-900">{{ t('navigation.stats') }}</h2>
      <p class="text-gray-600 mt-1">آمار و نمودارهای بازدید سایت</p>
    </div>

    <!-- Charts Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <!-- Line Chart -->
      <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-semibold text-gray-900">{{ t('stats.visitsByDay') }}</h3>
          <button
            @click="exportLineChart"
            class="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors flex items-center gap-1"
          >
            <DocumentArrowDownIcon class="h-4 w-4" />
            {{ t('stats.exportPdf') }}
          </button>
        </div>
        <div class="h-80">
          <Line
            ref="lineChart"
            :data="lineChartData"
            :options="lineChartOptions"
          />
        </div>
      </div>

      <!-- Pie Chart -->
      <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-semibold text-gray-900">{{ t('stats.visitsByCountry') }}</h3>
          <button
            @click="exportPieChart"
            class="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors flex items-center gap-1"
          >
            <DocumentArrowDownIcon class="h-4 w-4" />
            {{ t('stats.exportPdf') }}
          </button>
        </div>
        <div class="h-80">
          <Pie
            ref="pieChart"
            :data="pieChartData"
            :options="pieChartOptions"
          />
        </div>
      </div>
    </div>

    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600">کل بازدیدها</p>
            <p class="text-2xl font-bold text-gray-900">45,678</p>
            <p class="text-sm text-green-600 mt-1">+12.5%</p>
          </div>
          <EyeIcon class="h-8 w-8 text-blue-500" />
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600">بازدید امروز</p>
            <p class="text-2xl font-bold text-gray-900">1,234</p>
            <p class="text-sm text-green-600 mt-1">+8.3%</p>
          </div>
          <UserIcon class="h-8 w-8 text-green-500" />
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600">کاربران جدید</p>
            <p class="text-2xl font-bold text-gray-900">456</p>
            <p class="text-sm text-red-600 mt-1">-2.1%</p>
          </div>
          <UserPlusIcon class="h-8 w-8 text-purple-500" />
        </div>
      </div>

      <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-gray-600">نرخ پرش</p>
            <p class="text-2xl font-bold text-gray-900">23.4%</p>
            <p class="text-sm text-green-600 mt-1">-5.2%</p>
          </div>
          <ArrowTrendingUpIcon class="h-8 w-8 text-orange-500" />
        </div>
      </div>
    </div>

    <!-- Country Ranking -->
    <div class="bg-white rounded-xl shadow-sm p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4">رتبه‌بندی کشورها</h3>
      <div class="space-y-3">
        <div
          v-for="(country, index) in topCountries"
          :key="country.name"
          class="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
        >
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
              {{ index + 1 }}
            </div>
            <span class="font-medium text-gray-900">{{ country.name }}</span>
          </div>
          <div class="flex items-center space-x-3">
            <div class="text-sm text-gray-600">{{ country.visits.toLocaleString() }} بازدید</div>
            <div class="w-24 bg-gray-200 rounded-full h-2">
              <div
                class="bg-blue-500 h-2 rounded-full"
                :style="{ width: `${(country.visits / maxVisits) * 100}%` }"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  EyeIcon,
  UserIcon,
  UserPlusIcon,
  ArrowTrendingUpIcon,
  DocumentArrowDownIcon
} from '@heroicons/vue/24/outline'
import { Line, Pie } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  ChartEvent
} from 'chart.js'
import { html2canvas } from 'html2canvas'
import jsPDF from 'jspdf'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
)

const { t } = useI18n()

const lineChart = ref<any>(null)
const pieChart = ref<any>(null)

// Line Chart Data
const lineChartData = ref({
  labels: [
    t('stats.monday'),
    t('stats.tuesday'),
    t('stats.wednesday'),
    t('stats.thursday'),
    t('stats.friday'),
    t('stats.saturday'),
    t('stats.sunday')
  ],
  datasets: [{
    label: 'بازدید',
    data: [1200, 1900, 1500, 2500, 2200, 1800, 2100],
    borderColor: 'rgb(59, 130, 246)',
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    tension: 0.4,
    fill: true
  }]
})

const lineChartOptions = ref({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      mode: 'index',
      intersect: false,
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      titleColor: 'white',
      bodyColor: 'white',
      borderColor: 'rgb(59, 130, 246)',
      borderWidth: 1
    }
  },
  scales: {
    x: {
      grid: {
        display: false
      },
      ticks: {
        color: '#6B7280',
        font: {
          size: 12
        }
      }
    },
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)'
      },
      ticks: {
        color: '#6B7280',
        font: {
          size: 12
        }
      }
    }
  }
})

// Pie Chart Data
const pieChartData = ref({
  labels: ['ایران', 'آمریکا', 'کانادا', 'آلمان', 'بریتانیا', 'فرانسه', 'سایر'],
  datasets: [{
    data: [8500, 6200, 4800, 3900, 3600, 3100, 15578],
    backgroundColor: [
      '#3B82F6',
      '#10B981',
      '#F59E0B',
      '#EF4444',
      '#8B5CF6',
      '#EC4899',
      '#6B7280'
    ],
    borderWidth: 2,
    borderColor: '#ffffff'
  }]
})

const pieChartOptions = ref({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'right',
      labels: {
        color: '#6B7280',
        font: {
          size: 12
        },
        padding: 15
      }
    },
    tooltip: {
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      titleColor: 'white',
      bodyColor: 'white',
      borderColor: 'rgb(59, 130, 246)',
      borderWidth: 1,
      callbacks: {
        label: function(context: any) {
          const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0)
          const percentage = ((context.parsed / total) * 100).toFixed(1)
          return `${context.label}: ${context.parsed.toLocaleString()} (${percentage}%)`
        }
      }
    }
  }
})

// Country data for ranking
const topCountries = ref([
  { name: 'ایران', visits: 8500 },
  { name: 'آمریکا', visits: 6200 },
  { name: 'کانادا', visits: 4800 },
  { name: 'آلمان', visits: 3900 },
  { name: 'بریتانیا', visits: 3600 }
])

const maxVisits = ref(8500)

// Export functions
const exportLineChart = async () => {
  if (!lineChart.value) return
  
  try {
    const canvas = await html2canvas(lineChart.value.$el)
    const imgData = canvas.toDataURL('image/png')
    
    const pdf = new jsPDF('landscape', 'mm', 'a4')
    const imgWidth = 250
    const imgHeight = (canvas.height * imgWidth) / canvas.width
    
    pdf.addImage(imgData, 'PNG', 20, 20, imgWidth, imgHeight)
    pdf.save('visits-by-day.pdf')
    
    $toast.success('نمودار با موفقیت ذخیره شد')
  } catch (error) {
    console.error('Failed to export chart:', error)
    $toast.error('خطا در ذخیره نمودار')
  }
}

const exportPieChart = async () => {
  if (!pieChart.value) return
  
  try {
    const canvas = await html2canvas(pieChart.value.$el)
    const imgData = canvas.toDataURL('image/png')
    
    const pdf = new jsPDF('landscape', 'mm', 'a4')
    const imgWidth = 250
    const imgHeight = (canvas.height * imgWidth) / canvas.width
    
    pdf.addImage(imgData, 'PNG', 20, 20, imgWidth, imgHeight)
    pdf.save('visits-by-country.pdf')
    
    $toast.success('نمودار با موفقیت ذخیره شد')
  } catch (error) {
    console.error('Failed to export chart:', error)
    $toast.error('خطا در ذخیره نمودار')
  }
}

// Generate random data on component mount
onMounted(() => {
  // Generate random line chart data
  lineChartData.value.datasets[0].data = Array.from({ length: 7 }, () => 
    Math.floor(Math.random() * 2000) + 1000
  )
  
  // Generate random pie chart data
  const baseData = [8500, 6200, 4800, 3900, 3600, 3100]
  const remaining = 45678 - baseData.reduce((a, b) => a + b, 0)
  pieChartData.value.datasets[0].data = [...baseData, remaining]
  
  // Update max visits
  maxVisits.value = Math.max(...pieChartData.value.datasets[0].data)
})
</script>