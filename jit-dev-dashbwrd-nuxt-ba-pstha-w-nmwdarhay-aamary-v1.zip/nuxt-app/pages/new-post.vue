<template>
  <div class="max-w-4xl mx-auto">
    <!-- Header -->
    <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
      <h2 class="text-2xl font-bold text-gray-900">{{ t('navigation.newPost') }}</h2>
      <p class="text-gray-600 mt-1">فرم ثبت پست جدید</p>
    </div>

    <!-- Form -->
    <div class="bg-white rounded-xl shadow-sm p-6">
      <form @submit.prevent="submitForm" class="space-y-6">
        <!-- ID Field -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">
            {{ t('newPost.id') }} *
          </label>
          <input
            v-model="form.id"
            type="number"
            required
            :min="1"
            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="شناسه پست را وارد کنید"
          />
          <p class="mt-1 text-sm text-gray-500">یک عدد منحصر به فرد برای شناسه پست</p>
        </div>

        <!-- Title Field -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">
            {{ t('newPost.title') }} *
          </label>
          <input
            v-model="form.title"
            type="text"
            required
            :pattern="[a-zA-Z0-9\s\-]+"
            @input="validateTitle"
            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            :class="[
              titleError ? 'border-red-300' : '',
              form.title && !titleError ? 'border-green-300' : ''
            ]"
            placeholder="عنوان پست را به انگلیسی وارد کنید"
          />
          <div v-if="titleError" class="mt-1 text-sm text-red-600">
            {{ t('newPost.titleError') }}
          </div>
          <div v-else-if="form.title && !titleError" class="mt-1 text-sm text-green-600">
            ✓ عنوان معتبر است
          </div>
          <p v-else class="mt-1 text-sm text-gray-500">
            عنوان باید فقط شامل حروف انگلیسی، اعداد و فاصله باشد
          </p>
        </div>

        <!-- Body Field -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">
            {{ t('newPost.body') }} *
          </label>
          <textarea
            v-model="form.body"
            required
            rows="8"
            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            placeholder="متن کامل پست را اینجا وارد کنید..."
          />
          <div class="mt-1 text-sm text-gray-500">
            {{ form.body.length }} / 2000 کاراکتر
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-4 pt-4 border-t border-gray-200">
          <button
            type="button"
            @click="resetForm"
            class="px-6 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
          >
            ریست فرم
          </button>
          <button
            type="submit"
            :disabled="!isFormValid || submitting"
            class="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 flex items-center space-x-2"
          >
            <DocumentTextIcon class="h-5 w-5" />
            <span>{{ submitting ? 'در حال ارسال...' : t('newPost.submit') }}</span>
          </button>
        </div>
      </form>
    </div>

    <!-- Preview Card -->
    <div v-if="isFormValid" class="mt-6 bg-white rounded-xl shadow-sm p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4">پیش نمایش پست</h3>
      <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
        <div class="flex items-start space-x-3">
          <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
            U
          </div>
          <div class="flex-1">
            <h4 class="font-medium text-gray-900">{{ form.title }}</h4>
            <p class="text-sm text-gray-500 mt-1">شناسه: {{ form.id }}</p>
            <p class="text-gray-700 mt-2">{{ form.body }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { DocumentTextIcon } from '@heroicons/vue/24/outline'

const { t } = useI18n()
const postsStore = usePostsStore()

const form = ref({
  id: '',
  title: '',
  body: ''
})

const submitting = ref(false)
const titleError = ref(false)
const titleValidationMessage = ref('')

const isFormValid = computed(() => {
  return (
    form.value.id.trim() !== '' &&
    form.value.title.trim() !== '' &&
    form.value.body.trim() !== '' &&
    !titleError.value &&
    !isNaN(Number(form.value.id)) &&
    Number(form.value.id) > 0
  )
})

const validateTitle = () => {
  const value = form.value.title
  
  // Check if contains non-English characters
  if (value && /[^a-zA-Z0-9\s\-]/.test(value)) {
    titleError.value = true
    titleValidationMessage.value = t('newPost.titleError')
    return false
  }
  
  titleError.value = false
  titleValidationMessage.value = ''
  return true
}

const resetForm = () => {
  form.value = {
    id: '',
    title: '',
    body: ''
  }
  titleError.value = false
  titleValidationMessage.value = ''
}

const submitForm = async () => {
  if (!isFormValid.value || submitting.value) return
  
  submitting.value = true
  
  try {
    const postData = {
      id: parseInt(form.value.id),
      title: form.value.title,
      body: form.value.body
    }
    
    await postsStore.createPost(postData)
    
    // Show success message
    $toast.success(t('newPost.createSuccess'))
    
    // Reset form
    resetForm()
    
    // Optional: redirect to posts page after delay
    setTimeout(() => {
      useRouter().push('/posts')
    }, 2000)
    
  } catch (error) {
    console.error('Failed to create post:', error)
    $toast.error(t('newPost.createError'))
  } finally {
    submitting.value = false
  }
}

// Watch form changes for validation
watch(() => form.value.title, () => {
  validateTitle()
})

// Auto-generate ID if empty and user types in title
watch(() => form.value.title, () => {
  if (!form.value.id && form.value.title.trim()) {
    // Generate a simple ID based on title length + timestamp
    const timestamp = Date.now().toString().slice(-4)
    const baseId = form.value.title.length.toString()
    form.value.id = baseId + timestamp
  }
})
</script>