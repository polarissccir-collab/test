<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="bg-white rounded-xl shadow-sm p-6">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 class="text-2xl font-bold text-gray-900">{{ t('navigation.posts') }}</h2>
        <div class="flex items-center gap-4">
          <!-- Search -->
          <div class="relative">
            <input
              v-model="searchQuery"
              type="text"
              :placeholder="t('posts.search')"
              class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          </div>
          
          <!-- Export to Excel -->
          <button
            @click="exportToExcel"
            class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors flex items-center gap-2"
          >
            <DocumentArrowDownIcon class="h-5 w-5" />
            Excel
          </button>
        </div>
      </div>
    </div>

    <!-- Data Grid -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
      <!-- Table Header -->
      <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-4">
            <input
              type="checkbox"
              :checked="selectAll"
              @change="toggleSelectAll"
              class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span class="text-sm text-gray-600">{{ selectedPostsCount }} selected</span>
          </div>
          <div class="flex items-center space-x-2">
            <button
              @click="sortTable('id')"
              class="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded flex items-center gap-1"
            >
              <span>ردیف</span>
              <ArrowPathIcon class="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <!-- Table -->
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  :checked="selectAll"
                  @change="toggleSelectAll"
                  class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ t('posts.id') }}
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ t('posts.title') }}
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ t('posts.body') }}
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ t('posts.actions') }}
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr v-if="postsStore.loading">
              <td colspan="5" class="px-6 py-12 text-center">
                <div class="flex items-center justify-center space-x-2">
                  <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500"></div>
                  <span class="text-gray-600">{{ t('common.loading') }}</span>
                </div>
              </td>
            </tr>
            <tr v-else-if="filteredPosts.length === 0">
              <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                هیچ پستی یافت نشد
              </td>
            </tr>
            <tr
              v-else
              v-for="post in filteredPosts"
              :key="post.id"
              :class="[
                selectedPosts.includes(post.id.toString()) ? 'bg-blue-50' : '',
                'hover:bg-gray-50 transition-colors'
              ]"
            >
              <td class="px-6 py-4 whitespace-nowrap">
                <input
                  type="checkbox"
                  :checked="selectedPosts.includes(post.id.toString())"
                  @change="togglePostSelection(post.id.toString())"
                  class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {{ post.id }}
              </td>
              <td class="px-6 py-4">
                <div class="text-sm text-gray-900 max-w-xs truncate" :title="post.title">
                  {{ post.title }}
                </div>
              </td>
              <td class="px-6 py-4">
                <div class="text-sm text-gray-600 max-w-xs truncate" :title="post.body">
                  {{ post.body }}
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                <button
                  @click="showComments(post)"
                  class="text-blue-600 hover:text-blue-900 transition-colors"
                >
                  <EyeIcon class="h-5 w-5" />
                </button>
                <button
                  @click="editPost(post)"
                  class="text-green-600 hover:text-green-900 transition-colors"
                >
                  <PencilIcon class="h-5 w-5" />
                </button>
                <button
                  @click="confirmDelete(post)"
                  class="text-red-600 hover:text-red-900 transition-colors"
                >
                  <TrashIcon class="h-5 w-5" />
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
        <div class="flex items-center justify-between">
          <div class="text-sm text-gray-700">
            نمایش {{ (postsStore.currentPage - 1) * postsStore.postsPerPage + 1 }} تا 
            {{ Math.min(postsStore.currentPage * postsStore.postsPerPage, postsStore.totalPosts) }} 
            از {{ postsStore.totalPosts }} پست
          </div>
          <div class="flex items-center space-x-2">
            <button
              @click="previousPage"
              :disabled="postsStore.currentPage === 1"
              :class="[
                'px-3 py-1 text-sm rounded',
                postsStore.currentPage === 1
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              ]"
            >
              قبلی
            </button>
            <button
              v-for="page in displayedPages"
              :key="page"
              @click="goToPage(page)"
              :class="[
                'px-3 py-1 text-sm rounded',
                postsStore.currentPage === page
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              ]"
            >
              {{ page }}
            </button>
            <button
              @click="nextPage"
              :disabled="postsStore.currentPage === postsStore.totalPages"
              :class="[
                'px-3 py-1 text-sm rounded',
                postsStore.currentPage === postsStore.totalPages
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              ]"
            >
              بعدی
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Comments Modal -->
  <div v-if="showCommentsModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-xl max-w-4xl w-full mx-4 max-h-[80vh] overflow-hidden">
      <div class="p-6 border-b border-gray-200">
        <div class="flex items-center justify-between">
          <h3 class="text-lg font-semibold text-gray-900">نظرات پست</h3>
          <button
            @click="showCommentsModal = false"
            class="text-gray-400 hover:text-gray-600"
          >
            <XMarkIcon class="h-6 w-6" />
          </button>
        </div>
      </div>
      <div class="p-6 overflow-y-auto max-h-[60vh]">
        <div v-if="loadingComments" class="flex items-center justify-center py-8">
          <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500"></div>
        </div>
        <div v-else-if="comments.length === 0" class="text-center py-8 text-gray-500">
          نظری برای این پست وجود ندارد
        </div>
        <div v-else class="space-y-4">
          <div
            v-for="comment in comments"
            :key="comment.id"
            class="border border-gray-200 rounded-lg p-4"
          >
            <div class="flex items-start space-x-3">
              <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
                {{ comment.name.charAt(0).toUpperCase() }}
              </div>
              <div class="flex-1">
                <h4 class="font-medium text-gray-900">{{ comment.name }}</h4>
                <p class="text-sm text-gray-500">{{ comment.email }}</p>
                <p class="text-gray-700 mt-2">{{ comment.body }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Edit Modal -->
  <div v-if="showEditModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full mx-4">
      <div class="p-6 border-b border-gray-200">
        <div class="flex items-center justify-between">
          <h3 class="text-lg font-semibold text-gray-900">ویرایش پست</h3>
          <button
            @click="showEditModal = false"
            class="text-gray-400 hover:text-gray-600"
          >
            <XMarkIcon class="h-6 w-6" />
          </button>
        </div>
      </div>
      <div class="p-6">
        <form @submit.prevent="savePost" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">{{ t('posts.id') }}</label>
            <input
              type="text"
              v-model="editForm.id"
              disabled
              class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">{{ t('posts.title') }}</label>
            <input
              type="text"
              v-model="editForm.title"
              required
              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">{{ t('posts.body') }}</label>
            <textarea
              v-model="editForm.body"
              required
              rows="4"
              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div class="flex justify-end space-x-3">
            <button
              type="button"
              @click="showEditModal = false"
              class="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              انصراف
            </button>
            <button
              type="submit"
              :disabled="postsStore.loading"
              class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50"
            >
              {{ postsStore.loading ? 'در حال ذخیره...' : 'ذخیره' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Delete Confirmation Modal -->
  <div v-if="showDeleteModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
      <div class="p-6">
        <div class="flex items-center space-x-3 mb-4">
          <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <ExclamationTriangleIcon class="h-6 w-6 text-red-600" />
          </div>
          <h3 class="text-lg font-semibold text-gray-900">تایید حذف</h3>
        </div>
        <p class="text-gray-600 mb-6">
          {{ t('posts.confirmDelete') }}
        </p>
        <div class="flex justify-end space-x-3">
          <button
            @click="showDeleteModal = false"
            class="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
          >
            {{ t('common.cancel') }}
          </button>
          <button
            @click="deletePost"
            :disabled="postsStore.loading"
            class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50"
          >
            {{ postsStore.loading ? 'در حال حذف...' : t('posts.delete') }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  MagnifyingGlassIcon,
  DocumentArrowDownIcon,
  ArrowPathIcon,
  EyeIcon,
  PencilIcon,
  TrashIcon,
  XMarkIcon,
  ExclamationTriangleIcon
} from '@heroicons/vue/24/outline'

const { t } = useI18n()
const postsStore = usePostsStore()

const searchQuery = ref('')
const selectedPosts = ref<string[]>([])
const showCommentsModal = ref(false)
const showEditModal = ref(false)
const showDeleteModal = ref(false)
const loadingComments = ref(false)
const comments = ref<any[]>([])
const editForm = ref({
  id: '',
  title: '',
  body: ''
})

const selectedPost = ref<any>(null)

// Computed
const filteredPosts = computed(() => {
  if (!searchQuery.value) return postsStore.paginatedPosts
  
  const query = searchQuery.value.toLowerCase()
  return postsStore.paginatedPosts.filter(post =>
    post.title.toLowerCase().includes(query) ||
    post.body.toLowerCase().includes(query)
  )
})

const selectAll = computed({
  get: () => filteredPosts.value.length > 0 && filteredPosts.value.length === selectedPosts.value.length,
  set: (value) => {
    if (value) {
      selectedPosts.value = filteredPosts.value.map(p => p.id.toString())
    } else {
      selectedPosts.value = []
    }
  }
})

const selectedPostsCount = computed(() => selectedPosts.value.length)

const displayedPages = computed(() => {
  const pages = []
  const current = postsStore.currentPage
  const total = postsStore.totalPages
  
  // Show up to 7 pages around current page
  for (let i = Math.max(1, current - 3); i <= Math.min(total, current + 3); i++) {
    pages.push(i)
  }
  
  return pages
})

// Methods
const togglePostSelection = (postId: string) => {
  postsStore.togglePostSelection(postId)
}

const toggleSelectAll = () => {
  postsStore.selectAllPosts()
}

const previousPage = () => {
  if (postsStore.currentPage > 1) {
    postsStore.currentPage--
  }
}

const nextPage = () => {
  if (postsStore.currentPage < postsStore.totalPages) {
    postsStore.currentPage++
  }
}

const goToPage = (page: number) => {
  postsStore.currentPage = page
}

const showComments = async (post: any) => {
  selectedPost.value = post
  showCommentsModal.value = true
  loadingComments.value = true
  
  try {
    comments.value = await postsStore.getComments(post.id)
  } catch (error) {
    console.error('Failed to fetch comments:', error)
  } finally {
    loadingComments.value = false
  }
}

const editPost = (post: any) => {
  selectedPost.value = post
  editForm.value = {
    id: post.id.toString(),
    title: post.title,
    body: post.body
  }
  showEditModal.value = true
}

const savePost = async () => {
  if (!selectedPost.value) return
  
  try {
    await postsStore.updatePost(selectedPost.value.id, {
      title: editForm.value.title,
      body: editForm.value.body
    })
    
    showEditModal.value = false
    $toast.success(t('posts.saveSuccess'))
  } catch (error) {
    $toast.error(t('posts.saveError'))
  }
}

const confirmDelete = (post: any) => {
  selectedPost.value = post
  showDeleteModal.value = true
}

const deletePost = async () => {
  if (!selectedPost.value) return
  
  try {
    await postsStore.deletePost(selectedPost.value.id)
    showDeleteModal.value = false
    $toast.success(t('posts.deleteSuccess'))
  } catch (error) {
    $toast.error(t('posts.deleteError'))
  }
}

const sortTable = (column: string) => {
  // Implement sorting logic
}

const exportToExcel = () => {
  // Implement Excel export logic
  $toast.success('Excel export functionality would be implemented here')
}

// Fetch posts on component mount
onMounted(async () => {
  try {
    await postsStore.fetchPosts()
  } catch (error) {
    $toast.error('Failed to load posts')
  }
})
</script>