<template>
  <div class="min-h-screen">
    <div class="max-w-7xl mx-auto">
      <!-- Big Monitor Container -->
      <div class="bg-gray-900 rounded-2xl shadow-2xl p-6 mb-8">
        <div class="bg-black rounded-xl p-8 relative overflow-hidden">
          <!-- Monitor Frame -->
          <div class="absolute inset-4 border-2 border-gray-700 rounded-lg"></div>
          
          <!-- Monitor Stand -->
          <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 w-24 h-4 bg-gray-700 rounded"></div>
          <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-32 h-8 bg-gray-600 rounded-t-lg"></div>

          <!-- Screen Content -->
          <div class="relative h-full min-h-[500px]">
            <!-- Slider -->
            <div class="relative h-full overflow-hidden rounded-lg">
              <!-- Slides -->
              <div 
                v-for="(slide, index) in slides"
                :key="slide.id"
                :class="[
                  'absolute inset-0 transition-all duration-500 ease-in-out',
                  currentSlide === index ? 'opacity-100' : 'opacity-0'
                ]"
              >
                <img 
                  :src="slide.image" 
                  :alt="slide.title"
                  class="w-full h-full object-cover"
                />
                <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div class="absolute bottom-8 left-8 text-white">
                  <h3 class="text-3xl font-bold mb-2">{{ slide.title }}</h3>
                  <p class="text-lg opacity-90">{{ slide.description }}</p>
                </div>
              </div>

              <!-- Navigation Arrows -->
              <button 
                @click="prevSlide"
                class="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors"
              >
                <ChevronLeftIcon class="h-6 w-6 text-white" />
              </button>
              <button 
                @click="nextSlide"
                class="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors"
              >
                <ChevronRightIcon class="h-6 w-6 text-white" />
              </button>

              <!-- Dots Indicator -->
              <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                <button
                  v-for="(_, index) in slides"
                  :key="index"
                  @click="goToSlide(index)"
                  :class="[
                    'w-3 h-3 rounded-full transition-colors',
                    currentSlide === index ? 'bg-white' : 'bg-white/50'
                  ]"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Quick Stats -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">کل پست‌ها</p>
              <p class="text-2xl font-bold text-gray-900">1,234</p>
            </div>
            <DocumentTextIcon class="h-8 w-8 text-blue-500" />
          </div>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">بازدید امروز</p>
              <p class="text-2xl font-bold text-gray-900">5,678</p>
            </div>
            <EyeIcon class="h-8 w-8 text-green-500" />
          </div>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">کاربران فعال</p>
              <p class="text-2xl font-bold text-gray-900">892</p>
            </div>
              <UserGroupIcon class="h-8 w-8 text-purple-500" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  DocumentTextIcon,
  EyeIcon,
  UserGroupIcon
} from '@heroicons/vue/24/outline'

const currentSlide = ref(0)
let autoSlideInterval: NodeJS.Timeout

const slides = [
  {
    id: 1,
    title: 'به دنیای نوین خوش آمدید',
    description: 'تجربه‌ای متفاوت از وب اپلیکیشن‌های مدرن',
    image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=1200&h=600&fit=crop'
  },
  {
    id: 2,
    title: 'فناوری نوین',
    description: 'با آخرین تکنولوژی‌های روز دنیا آشنا شوید',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=600&fit=crop'
  },
  {
    id: 3,
    title: 'طراحی زیبا',
    description: 'رابط کاربری جذاب و کاربرپسند',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=600&fit=crop'
  },
  {
    id: 4,
    title: 'عملکرد بالا',
    description: 'سرعت و عملکرد بی‌نظیر در هر شرایط',
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=1200&h=600&fit=crop'
  },
  {
    id: 5,
    title: 'امنیت کامل',
    description: 'محیطی امن برای کار شما',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&h=600&fit=crop'
  }
]

const nextSlide = () => {
  currentSlide.value = (currentSlide.value + 1) % slides.length
}

const prevSlide = () => {
  currentSlide.value = (currentSlide.value - 1 + slides.length) % slides.length
}

const goToSlide = (index: number) => {
  currentSlide.value = index
}

const startAutoSlide = () => {
  autoSlideInterval = setInterval(nextSlide, 5000)
}

const stopAutoSlide = () => {
  clearInterval(autoSlideInterval)
}

onMounted(() => {
  startAutoSlide()
})

onUnmounted(() => {
  stopAutoSlide()
})
</script>