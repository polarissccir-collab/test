import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const usePostsStore = defineStore('posts', () => {
  const posts = ref<any[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)
  const currentPage = ref(1)
  const postsPerPage = 10
  const totalPosts = ref(0)
  const selectedPosts = ref<string[]>([])

  const paginatedPosts = computed(() => {
    const startIndex = (currentPage.value - 1) * postsPerPage
    const endIndex = startIndex + postsPerPage
    return posts.value.slice(startIndex, endIndex)
  })

  const totalPages = computed(() => Math.ceil(totalPosts.value / postsPerPage))

  const fetchPosts = async () => {
    loading.value = true
    error.value = null
    try {
      const response = await fetch(`${useRuntimeConfig().public.apiBaseUrl}/posts`)
      if (!response.ok) throw new Error('Failed to fetch posts')
      
      const data = await response.json()
      posts.value = data
      totalPosts.value = data.length
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Unknown error'
      throw err
    } finally {
      loading.value = false
    }
  }

  const updatePost = async (postId: number, postData: any) => {
    loading.value = true
    error.value = null
    try {
      const response = await fetch(`${useRuntimeConfig().public.apiBaseUrl}/posts/${postId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      })
      
      if (!response.ok) throw new Error('Failed to update post')
      
      const index = posts.value.findIndex(p => p.id === postId)
      if (index !== -1) {
        posts.value[index] = { ...posts.value[index], ...postData }
      }
      
      return true
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Unknown error'
      throw err
    } finally {
      loading.value = false
    }
  }

  const deletePost = async (postId: number) => {
    loading.value = true
    error.value = null
    try {
      const response = await fetch(`${useRuntimeConfig().public.apiBaseUrl}/posts/${postId}`, {
        method: 'DELETE'
      })
      
      if (!response.ok) throw new Error('Failed to delete post')
      
      posts.value = posts.value.filter(p => p.id !== postId)
      totalPosts.value--
      
      return true
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Unknown error'
      throw err
    } finally {
      loading.value = false
    }
  }

  const createPost = async (postData: any) => {
    loading.value = true
    error.value = null
    try {
      const response = await fetch(`${useRuntimeConfig().public.apiBaseUrl}/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      })
      
      if (!response.ok) throw new Error('Failed to create post')
      
      const newPost = await response.json()
      posts.value.unshift(newPost)
      totalPosts.value++
      
      return newPost
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Unknown error'
      throw err
    } finally {
      loading.value = false
    }
  }

  const getComments = async (postId: number) => {
    try {
      const response = await fetch(`${useRuntimeConfig().public.apiBaseUrl}/comments?postId=${postId}`)
      if (!response.ok) throw new Error('Failed to fetch comments')
      
      return await response.json()
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Unknown error'
      throw err
    }
  }

  const togglePostSelection = (postId: string) => {
    const index = selectedPosts.value.indexOf(postId)
    if (index === -1) {
      selectedPosts.value.push(postId)
    } else {
      selectedPosts.value.splice(index, 1)
    }
  }

  const selectAllPosts = () => {
    if (selectedPosts.value.length === paginatedPosts.value.length) {
      selectedPosts.value = []
    } else {
      selectedPosts.value = paginatedPosts.value.map(p => p.id.toString())
    }
  }

  return {
    posts,
    loading,
    error,
    currentPage,
    postsPerPage,
    totalPosts,
    selectedPosts,
    paginatedPosts,
    totalPages,
    fetchPosts,
    updatePost,
    deletePost,
    createPost,
    getComments,
    togglePostSelection,
    selectAllPosts
  }
})