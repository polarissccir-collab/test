<template>
  <aside
    :class="[
      'fixed lg:sticky top-16 left-0 h-[calc(100vh-4rem)] w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out z-40',
      sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
    ]"
  >
    <div class="flex flex-col h-full">
      <!-- Sidebar Header -->
      <div class="flex items-center justify-between p-4 border-b border-gray-200">
        <h3 class="text-sm font-medium text-gray-700">منو</h3>
        <button 
          @click="toggleSidebar"
          class="lg:hidden p-1 rounded-md text-gray-500 hover:bg-gray-100"
        >
          <XMarkIcon class="h-5 w-5" />
        </button>
      </div>

      <!-- Navigation -->
      <nav class="flex-1 p-4 space-y-2">
        <NuxtLink
          v-for="item in navigationItems"
          :key="item.to"
          :to="item.to"
          class="flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200"
          :class="[
            $route.path === item.to
              ? 'bg-blue-50 text-blue-700'
              : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
          ]"
        >
          <component :is="item.icon" class="h-5 w-5" />
          <span>{{ t(`navigation.${item.label}`) }}</span>
        </NuxtLink>
      </nav>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  HomeIcon,
  DocumentTextIcon,
  PlusCircleIcon,
  ChartBarIcon,
  XMarkIcon
} from '@heroicons/vue/24/outline'

const props = defineProps<{
  sidebarOpen: boolean
}>()

const emit = defineEmits<{
  'update:sidebarOpen': [value: boolean]
}>()

const { t } = useI18n()

const toggleSidebar = () => {
  emit('update:sidebarOpen', !props.sidebarOpen)
}

const navigationItems = [
  {
    to: '/',
    label: 'home',
    icon: HomeIcon
  },
  {
    to: '/posts',
    label: 'posts',
    icon: DocumentTextIcon
  },
  {
    to: '/new-post',
    label: 'newPost',
    icon: PlusCircleIcon
  },
  {
    to: '/stats',
    label: 'stats',
    icon: ChartBarIcon
  }
]
</script>