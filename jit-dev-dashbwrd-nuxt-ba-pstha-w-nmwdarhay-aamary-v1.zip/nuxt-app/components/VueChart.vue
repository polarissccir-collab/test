<template>
  <div class="relative h-full">
    <canvas ref="chartRef"></canvas>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue'
import { Chart, ChartType } from 'chart.js'

const props = defineProps<{
  type: ChartType
  data: any
  options?: any
}>()

const emit = defineEmits<{
  'chart-ready': [chart: Chart]
}>()

const chartRef = ref<HTMLCanvasElement | null>(null)
let chart: Chart | null = null

const initChart = () => {
  if (!chartRef.value) return

  if (chart) {
    chart.destroy()
  }

  chart = new Chart(chartRef.value, {
    type: props.type,
    data: props.data,
    options: props.options || {}
  })

  emit('chart-ready', chart)
}

const updateChart = () => {
  if (!chart) return
  
  chart.data = props.data
  chart.update()
}

onMounted(() => {
  initChart()
})

onUnmounted(() => {
  if (chart) {
    chart.destroy()
    chart = null
  }
})

watch(() => props.data, updateChart, { deep: true })
</script>