<template>
  <header class="bg-white shadow-sm border-b border-gray-200 fixed top-0 left-0 right-0 z-50">
    <div class="px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between items-center h-16">
        <!-- Logo and App Name -->
        <div class="flex items-center space-x-4">
          <button 
            @click="toggleSidebar" 
            class="lg:hidden p-2 rounded-md text-gray-600 hover:bg-gray-100"
          >
            <MenuIcon class="h-6 w-6" />
          </button>
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <span class="text-white font-bold text-sm">W</span>
            </div>
            <h1 class="text-xl font-bold text-gray-900">وب اپلیکیشن</h1>
          </div>
        </div>

        <!-- Page Title -->
        <div class="flex-1 text-center">
          <h2 class="text-lg font-semibold text-gray-800">{{ pageTitle }}</h2>
        </div>

        <!-- Back Button -->
        <button 
          v-if="showBackButton"
          @click="$router.back()"
          class="p-2 rounded-md text-gray-600 hover:bg-gray-100"
        >
          <ArrowLeftIcon class="h-6 w-6" />
        </button>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import {
  MenuIcon,
  ArrowLeftIcon
} from '@heroicons/vue/24/outline'

const props = defineProps<{
  sidebarOpen: boolean
  pageTitle: string
}>()

const emit = defineEmits<{
  'update:sidebarOpen': [value: boolean]
}>()

const route = useRoute()

const toggleSidebar = () => {
  emit('update:sidebarOpen', !props.sidebarOpen)
}

const showBackButton = computed(() => {
  return route.path !== '/'
})
</script>