export default defineNuxtPlugin({
  name: 'toast',
  dependsOn: ['i18n'],
  async setup() {
    const { $toast } = useNuxtApp()
    
    // Set up toastification
    $toast.defaultOptions = {
      timeout: 4000,
      closeOnClick: true,
      pauseOnFocusLoss: true,
      pauseOnHover: true,
      draggable: true,
      draggablePercent: 0.6,
      showCloseButtonOnHover: true,
      closeButton: 'button',
      icon: true,
      rtl: true,
      theme: 'light'
    }
  }
})