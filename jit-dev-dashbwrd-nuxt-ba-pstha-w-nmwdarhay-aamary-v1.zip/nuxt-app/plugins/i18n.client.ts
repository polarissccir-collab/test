export default defineNuxtPlugin({
  name: 'i18n',
  dependsOn: ['i18n'],
  async setup() {
    const { locale } = useI18n()
    const { $toast } = useNuxtApp()
    
    // Set initial locale
    const savedLocale = localStorage.getItem('locale')
    if (savedLocale) {
      locale.value = savedLocale
    }
    
    // Watch for locale changes
    watch(locale, (newLocale) => {
      localStorage.setItem('locale', newLocale)
    })
  }
})