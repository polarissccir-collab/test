export default defineNuxtConfig({
  modules: [
    '@nuxt/image',
    '@nuxtjs/tailwindcss',
    '@pinia/nuxt',
    '@nuxt/devtools',
    [
      'vue-i18n',
      {
        legacy: false,
        locale: 'fa',
        fallbackLocale: 'en',
        locales: {
          fa: {
            name: 'فارسی',
            file: 'fa.ts'
          },
          en: {
            name: 'English',
            file: 'en.ts'
          }
        }
      }
    ]
  ],
  i18n: {
    strategy: 'no_prefix',
    lazy: true,
    langDir: 'locales'
  },
  runtimeConfig: {
    public: {
      apiBaseUrl: 'https://jsonplaceholder.typicode.com'
    }
  },
  app: {
    head: {
      title: 'وب اپلیکیشن دانشگاهی',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'description', content: 'پروژه تمرینی دانشگاهی با Nuxt.js و Vue.js' },
        { name: 'theme-color', content: '#3B82F6' }
      ],
      link: [
        { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
      ]
    }
  },
  nitro: {
    preset: 'node-server'
  }
})