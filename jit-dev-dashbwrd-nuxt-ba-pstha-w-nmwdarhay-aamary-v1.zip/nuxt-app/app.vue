<template>
  <div class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <NuxtPage />
  </div>
</template>

<script setup lang="ts">
useHead({
  title: 'وب اپلیکیشن دانشگاهی',
  meta: [
    { charset: 'utf-8' },
    { name: 'viewport', content: 'width=device-width, initial-scale=1' },
    { name: 'description', content: 'پروژه تمرینی دانشگاهی با Nuxt.js و Vue.js' },
    { name: 'theme-color', content: '#3B82F6' }
  ]
})
</script>