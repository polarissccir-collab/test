export default {
  navigation: {
    home: 'Home',
    posts: 'Posts',
    newPost: 'New Post',
    stats: 'Statistics'
  },
  posts: {
    id: 'ID',
    title: 'Title',
    body: 'Body',
    actions: 'Actions',
    comments: 'Show Comments',
    edit: 'Edit',
    delete: 'Delete',
    search: 'Search...',
    confirmDelete: 'Are you sure you want to delete this post?',
    deleteSuccess: 'Post deleted successfully',
    deleteError: 'Error deleting post',
    saveSuccess: 'Post saved successfully',
    saveError: 'Error saving post',
    createSuccess: 'Post created successfully',
    createError: 'Error creating post'
  },
  newPost: {
    title: 'Post Title',
    body: 'Post Body',
    id: 'Post ID',
    submit: 'Create Post',
    titleError: 'Title must be in English',
    idRequired: 'ID is required',
    titleRequired: 'Title is required',
    bodyRequired: 'Body is required'
  },
  stats: {
    visitsByDay: 'Visits by Day of Week',
    visitsByCountry: 'Visits by Country',
    exportPdf: 'Export PDF',
    monday: 'Monday',
    tuesday: 'Tuesday',
    wednesday: 'Wednesday',
    thursday: 'Thursday',
    friday: 'Friday',
    saturday: 'Saturday',
    sunday: 'Sunday'
  },
  common: {
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    confirm: 'Confirm',
    cancel: 'Cancel'
  }
}