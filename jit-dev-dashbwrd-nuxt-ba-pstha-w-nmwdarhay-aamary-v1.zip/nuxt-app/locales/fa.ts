export default {
  navigation: {
    home: 'صفحه اصلی',
    posts: 'پست ها',
    newPost: 'پست جدید',
    stats: 'آمار بازدید'
  },
  posts: {
    id: 'شناسه',
    title: 'عنوان',
    body: 'متن',
    actions: 'عملیات',
    comments: 'نمایش نظرات',
    edit: 'ویرایش',
    delete: 'حذف',
    search: 'جستجو...',
    confirmDelete: 'آیا از حذف این پست مطمئن هستید؟',
    deleteSuccess: 'پست با موفقیت حذف شد',
    deleteError: 'خطا در حذف پست',
    saveSuccess: 'پست با موفقیت ذخیره شد',
    saveError: 'خطا در ذخیره پست',
    createSuccess: 'پست با موفقیت ایجاد شد',
    createError: 'خطا در ایجاد پست'
  },
  newPost: {
    title: 'عنوان پست',
    body: 'متن پست',
    id: 'شناسه پست',
    submit: 'ثبت پست',
    titleError: 'عنوان باید به انگلیسی باشد',
    idRequired: 'شناسه الزامی است',
    titleRequired: 'عنوان الزامی است',
    bodyRequired: 'متن الزامی است'
  },
  stats: {
    visitsByDay: 'آمار بازدید بر اساس روزهای هفته',
    visitsByCountry: 'آمار بازدید بر اساس کشورها',
    exportPdf: 'دانلود PDF',
    monday: 'دوشنبه',
    tuesday: 'سه‌شنبه',
    wednesday: 'چهارشنبه',
    thursday: 'پنج‌شنبه',
    friday: 'جمعه',
    saturday: 'شنبه',
    sunday: 'یکشنبه'
  },
  common: {
    loading: 'در حال بارگذاری...',
    error: 'خطا',
    success: 'موفقیت',
    confirm: 'تایید',
    cancel: 'انصراف'
  }
}